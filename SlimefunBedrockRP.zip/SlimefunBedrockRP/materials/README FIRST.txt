WARNING:
- Don't use this custom material on your personal Minecraft Addon Projects! I'm not a professional programmer and i make this material using the method of testing and failing...
  the wrong use of this materials can crash your world instantly, please, if you want to use it, you can.. but first take care about this and second give me credits, this taked
  me so much time to do.
  
- This is a rustic solution to a GeyserMC non-implementation to Armor mappings, it will not permanently implemented on this RP forever.